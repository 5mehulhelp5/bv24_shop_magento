var config = {
    paths: {
        orderItemStatus: 'Upgradeschmiede_OrderItemStatus/js/order-item-status'
    },
    shim: {
        orderItemStatus: { deps: ['jquery'] }
    }
};
